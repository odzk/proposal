# NUVCL-117 → NUVCL-120 — Nuvho Proposal System changes

Nothing in this zip has been pushed to GitHub, deployed to DigitalOcean, or deployed to the
Cloudflare Worker. It was all built and verified in an isolated sandbox clone. Drop these files
into your local `nuvho-proposal-system` checkout at the matching paths, then commit/push and
deploy as usual.

**Note:** the D1 migration below (`0012_staff_signature.sql`) has already been run by you against
production (`nuvho-proposals`) — that part is live. Everything else in this zip is not yet.

## File map

Copy each file to the same relative path in your checkout, overwriting what's there:

```
frontend/app/(app)/proposals/new/page.tsx
frontend/app/(app)/settings/user-settings/page.tsx
frontend/lib/types.ts
frontend/lib/documentModel.ts
frontend/components/proposal/ProposalDocument.tsx
frontend/app/globals.css
worker/schema.sql
worker/migrations/0012_staff_signature.sql   (already run against production D1 — keep for the record / other environments)
worker/src/routes/staff.ts
worker/src/index.ts
```

## What changed, per ticket

### NUVCL-117 — Per-user signature in User Settings
- New `staff.signature_method` / `staff.signature_data_url` columns (already applied to prod D1 by you).
- New worker routes `GET`/`PATCH /staff/me/signature` (`worker/src/routes/staff.ts`, wired in `worker/src/index.ts`), scoped strictly to the signed-in user's own staff record — no one can read or write another staff member's signature.
- `Settings → User Settings` now has a "My Signature" card (type name / draw signature, live preview, save).
- The proposal wizard's Signature step (Step 7) now pre-fills from this saved signature on **new** proposals only, and only into fields that are still empty — always overridable per proposal.

### NUVCL-118 — Remove Step 5 (Sender)
- The old Step 5 "Sender" step is gone. Steps renumbered 1–8 (was 1–9): Hotel Details → Services → Scope → Pricing → Cover Image → Terms → Signature → Preview & Save.
- Its AI email-composer and file-attachment upload were dropped entirely (this system is PDF/DOC generation only for now).
- The one piece of Step 5 that actually fed the generated PDF — the "personal message" opening paragraph — was kept and relocated to Step 1 (Hotel Details), alongside a new Account Manager picker. Nothing in the PDF output changed as a result.

### NUVCL-119 — Branded A4 cover templates
- Cover Image step now offers 4 branded full-page templates (Circles, Split, Editorial, Sidebar) alongside the existing photo gallery.
- Implemented as a `branded:<id>` sentinel value reusing the existing `coverUrl` field — no schema/migration/worker change needed.
- Rendering added to `ProposalDocument.tsx` (shared by the wizard preview, Proposal Details page, and the public client-accept page) plus matching print CSS in `globals.css`.

### NUVCL-120 — Preview/PDF fidelity + whitespace fix
- The wizard's Preview step (Step 8) no longer wraps the cover background in its own separate card — it now shows exactly what the generated PDF will look like.
- Fixed the large blank gap that could appear between sections (e.g. under "Background and Scope of Work") by consolidating all flowing sections into one shared `.doc-flow` wrapper, so page-margin padding is applied once per physical page instead of once per section.

## Verification already done (in the sandbox)
- `frontend`: `npx tsc --noEmit` — clean. `npm run build` — succeeds (only pre-existing, unrelated `<img>` lint warnings).
- `worker`: `npx tsc --noEmit` — clean.

## Deploy steps
1. Copy the files above into your checkout.
2. `git add`, commit, push — DigitalOcean App Platform will auto-deploy the frontend.
3. From `worker/`: `npx wrangler deploy` to ship the worker changes (routes + schema comment; the actual D1 columns are already live from your earlier migration run).
4. Sanity-check: Settings → User Settings shows the new "My Signature" card; a new proposal's Step 7 pre-fills from it; the wizard is 8 steps with no Sender step; Cover Image shows 4 branded template options; Preview/PDF no longer shows a boxed background or the Background/Scope whitespace gap.
